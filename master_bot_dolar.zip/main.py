
import asyncio
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, Bot
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes

# ✅ CONFIGURACIÓN
TOKEN = "7805827822:AAGkNiIN-vH8tuYa25Tn1nTbB57HFeoCnQQ"
USUARIO_TELEGRAM = "MasterDolARSL_bot"

bot = Bot(token=TOKEN)

# --- FUNCIONES API ---

def obtener_dolar_oficial():
    try:
        r = requests.get("https://dolarapi.com/v1/dolares/oficial")
        if r.status_code == 200:
            data = r.json()
            return round(data["compra"], 2), round(data["venta"], 2)
        return None, None
    except:
        return None, None

def obtener_tasas_plazo_fijo():
    return {
        "Banco Nación": "71% TNA",
        "Galicia": "72% TNA",
        "BBVA": "70% TNA",
        "Supervielle": "69% TNA",
        "Patagonia": "68% TNA",
    }

def obtener_dolares_bancos():
    try:
        r = requests.get("https://criptoya.com/api/dolar")
        if r.status_code == 200:
            data = r.json()
            bancos = {
                "Galicia": data.get("galicia", {}).get("precio", "N/D"),
                "BBVA": data.get("bbva", {}).get("precio", "N/D"),
                "Santander": data.get("santander", {}).get("precio", "N/D"),
                "Patagonia": data.get("patagonia", {}).get("precio", "N/D"),
                "Nación": data.get("bna", {}).get("precio", "N/D")
            }
            return bancos
        return {}
    except:
        return {}

# --- MENÚ PRINCIPAL ---

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("💵 Dólar Oficial", callback_data="dolar")],
        [InlineKeyboardButton("📈 Plazo Fijo", callback_data="plazo")],
        [InlineKeyboardButton("🏦 Bancos", callback_data="bancos")],
        [InlineKeyboardButton("🧑‍💼 Asesoramiento", url=f"https://t.me/{USUARIO_TELEGRAM}")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("👋 ¡Bienvenido a MASTER BOT DolAR!
Seleccioná una opción:", reply_markup=reply_markup)

# --- RESPUESTAS A BOTONES ---

async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "dolar":
        compra, venta = obtener_dolar_oficial()
        if compra and venta:
            mensaje = f"💵 *Dólar Oficial Hoy:*
Compra: ${compra}\nVenta: ${venta}"
        else:
            mensaje = "⚠️ No se pudo obtener la cotización."
        await query.edit_message_text(mensaje, parse_mode="Markdown")

    elif query.data == "plazo":
        tasas = obtener_tasas_plazo_fijo()
        mensaje = "📈 *Tasas Plazo Fijo:*\n" + "\n".join([f"{banco}: {tasa}" for banco, tasa in tasas.items()])
        await query.edit_message_text(mensaje, parse_mode="Markdown")

    elif query.data == "bancos":
        cotizaciones = obtener_dolares_bancos()
        if cotizaciones:
            mensaje = "🏦 *Cotización por Banco:*\n" + "\n".join([f"{banco}: ${valor}" for banco, valor in cotizaciones.items()])
        else:
            mensaje = "⚠️ No se pudieron obtener los valores bancarios."
        await query.edit_message_text(mensaje, parse_mode="Markdown")

# --- INICIAR BOT ---

if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(menu_callback))
    print("🚀 MASTER BOT DolAR funcionando...")
    app.run_polling()
