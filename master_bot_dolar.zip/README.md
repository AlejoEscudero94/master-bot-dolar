
# MASTER BOT DolAR

Un bot de Telegram que muestra:
- 💵 Cotización del Dólar Oficial (en tiempo real)
- 📈 Tasas de Plazo Fijo simuladas
- 🏦 Cotización en Bancos vía CriptoYa
- 🧑‍💼 Acceso directo a asesoramiento

## 🚀 Instrucciones para correrlo en Replit

1. Crea un nuevo proyecto en Replit (Python).
2. Subí estos archivos o pegá su contenido.
3. Asegurate de tener el archivo `requirements.txt`.
4. En "Run", usá este comando:
```bash
python3 main.py
```
